# LuaForge

基于 `mlua` 的 Rust ↔ Lua 插件化原生扩展运行时（参考 `doc/Lua GUI 桌面应用框架.md` 实现）。

## Workspace crates

- `luaforge-core`: 核心 trait、注册中心、权限网关、资源管理器、Lua 注册器
- `luaforge-macros`: 过程宏（当前提供兼容占位实现）
- `luaforge-plugins`: 内置插件（sys/console/json/timer/event/fs）
- `luaforge-runtime`: 宿主运行时整合入口

## 快速开始

```bash
cargo test -p luaforge-runtime
```
