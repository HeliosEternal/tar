# LuaForge 框架理解与架构设计说明

> 基于当前项目代码（`luaforge-core` / `luaforge-plugins` / `luaforge-runtime` / `luaforge-macros`）对系统目标、架构分层、核心能力与后续演进的总结。

---

## 1. 系统定位

LuaForge 的本质是一个 **Rust ↔ Lua 的插件化原生能力运行时**：

- 面向 Lua 脚本提供统一的系统能力命名空间（`forge.*`）。
- 用 Rust 生态实现高性能、可扩展、可治理的原生 API。
- 支持安全权限拦截、资源生命周期管理、插件动态管理与按需裁剪。

这使它不仅能作为 Lua GUI 宿主的能力底座，也可作为通用 Lua 应用运行时核心。

---

## 2. 整体分层架构理解

### 2.1 Core 层（`luaforge-core`）

框架内核，定义“规则与机制”：

- 插件协议：`ForgePlugin`
- 生命周期管理：`PluginRegistry`
- Lua 注册抽象：`LuaRegistrar`
- 权限系统：`PermissionGate`
- 资源系统：`ResourceManager`
- 上下文注入：`ForgeContext`
- 数据交换层：`exchange`（含 `LuaBuffer`）

### 2.2 Plugins 层（`luaforge-plugins`）

内置插件集合，定义“具体能力”：

- `forge.sys`：系统/环境信息
- `forge.console`：日志输出
- `forge.json`：JSON 编解码
- `forge.timer`：基础定时能力
- `forge.event`：事件总线
- `forge.fs`：文件系统（带权限）

### 2.3 Runtime 层（`luaforge-runtime`）

宿主整合入口，定义“启动与装配”：

- 创建 Lua VM
- 注入 `ForgeContext`
- 初始化并注册 `PluginRegistry` 的 Lua 管理接口
- 装配内置插件与插件工厂
- 对外暴露 `ForgeRuntime`（执行脚本/加载插件/卸载插件）

### 2.4 Macros 层（`luaforge-macros`）

开发者体验层（当前为占位实现）：

- `#[forge_plugin]`
- `#[forge_functions]`
- `#[guarded]`

目标是降低第三方插件开发成本，最终自动生成样板注册代码。

---

## 3. 核心设计能力解读

## 3.1 一切能力插件化

通过 `ForgePlugin` 统一接入协议，内置插件与用户插件走同一套生命周期和注册流程。收益：

- 可治理：加载、卸载、挂起、恢复
- 可演进：能力拆分与组合自然
- 可生态化：第三方插件接入门槛低

## 3.2 安全模型内建

`PermissionGate` + `PermissionPolicy` 实现多级策略：

- `Open` / `Prompt` / `AlwaysAsk` / `Deny`
- 支持权限前缀匹配（如 `fs` 规则覆盖 `fs.read`）
- Prompt 结果缓存以降低热路径开销
- 权限策略在 Rust 侧，Lua 只能通过公开 API 触发检查

## 3.3 资源生命周期治理

`ResourceManager` 使用句柄模型管理长生命周期对象：

- 插件向资源池注册资源，返回 `ResourceHandle`
- 按类型计数并支持配额限制，避免无界增长
- 可用于后续承载 TCP/UDP/WebSocket/连接池等常驻对象

## 3.4 Lua API 面向业务可用

`LuaRegistrar` 屏蔽 `mlua` 底层细节：

- `add_function`
- `add_guarded_function`
- `add_submodule`

插件作者以命名空间方式组织 API（例如 `forge.fs.*`），保持 Lua 侧可读性与一致性。

## 3.5 运行时可观测与可管理

`PluginRegistry` 已提供 Lua 侧管理接口：

- `forge.plugins.list()`
- `forge.plugins.info(id)`
- `forge.plugins.load(id)`
- `forge.plugins.unload(id)`
- `forge.plugins.suspend(id)`
- `forge.plugins.resume(id)`

这为宿主应用实现插件治理、诊断、后台管理面板打下基础。

---

## 4. 当前实现与目标蓝图对齐情况

### 已落地

- Workspace 分层结构完整
- 核心协议与治理能力可用
- 内置基础插件可运行
- Runtime 启动流程打通
- 集成测试（smoke）覆盖基础链路

### 待增强（关键下一步）

1. **宏系统实装**：从占位宏升级为真实代码生成能力。  
2. **异步模型升级**：`timer/event` 从阻塞式实现升级为 tokio 驱动。  
3. **插件指标完善**：`PluginStats` 增加真实调用统计与耗时采样。  
4. **高阶网络插件**：HTTP/TCP/UDP/WS 与连接池深度集成。  
5. **平台抽象层**：clipboard/hotkey/notification/dialog/shell 条件编译落地。  
6. **权限交互策略**：Prompt 从“全允许/全拒绝”扩展到可配置回调与持久化策略。  

---

## 5. 我对这个框架的设计结论

LuaForge 的核心价值不在“把 Rust 函数暴露给 Lua”，而在于：

- 用工程化的 **插件协议 + 权限治理 + 资源治理 + 生命周期治理**，把“原生能力开放”变成一个可持续演进的平台能力。
- 该架构已经具备优秀内核雏形，方向正确；后续重点是异步化、宏化、平台化和可观测性补齐。

如果按当前路径持续推进，它可以从“Lua GUI 宿主能力层”成长为通用的 Lua 应用原生扩展运行时底座。

---

## 6. 面向团队协作的补充规范

## 6.1 模块职责边界

- `luaforge-core`：只放抽象、治理机制、通用基础设施；不放具体业务插件逻辑。
- `luaforge-plugins`：只放插件实现；不反向依赖 runtime。
- `luaforge-runtime`：只负责装配与对外入口，避免承载具体能力逻辑。
- `luaforge-macros`：只做代码生成与语法糖，不嵌入运行时状态。

## 6.2 API 稳定性约定

- 对外 API 分级：`stable`（默认）、`experimental`（需 feature 标记）。
- `ForgePlugin`、`LuaRegistrar`、`PermissionGate` 变更需保向后兼容或提供迁移说明。
- Lua 侧模块命名统一 `forge.<domain>`，禁止破坏性重命名。

## 6.3 错误与日志约定

- 统一使用 `ForgeError` 分类，Lua 侧以字符串错误透出。
- 插件内部日志统一携带目标名（如 `forge.fs`），便于聚合检索。
- 高风险操作（文件删除、命令执行、网络监听）必须输出审计日志。

---

## 7. 插件接入模板（建议）

最小插件接入流程：

1. 定义插件结构体并实现 `ForgePlugin`。  
2. 在 `register` 中通过 `LuaRegistrar` 暴露命名空间函数。  
3. 为敏感函数使用 `add_guarded_function` 绑定权限。  
4. 在 `luaforge-plugins` 注册默认工厂（支持 `forge.plugins.load(id)`）。  
5. 补充 smoke 测试（至少包含：加载、调用、权限校验）。  

建议模板能力：

- `id()`：`forge.<domain>`（如 `forge.net.http`）
- `kind()`：内置能力用 `Builtin`，可选能力/第三方能力用 `User`
- `required_permissions()`：声明完整权限清单，避免“隐式能力”

---

## 8. 里程碑实施建议（工程版）

### M1：内核增强（1~2 周）

- 宏系统从占位版升级到可生成注册代码。
- `PluginRegistry` 增加调用计数与错误计数自动采样。
- 增加核心单元测试（permission/resource/registry）。

### M2：异步化改造（2~3 周）

- `timer/event` 全面切换 tokio 非阻塞模型。
- 增加 Lua 回调调度保护（超时/panic 隔离）。
- 为长连接对象引入资源句柄回收策略。

### M3：网络与平台能力（3~4 周）

- 网络插件：`http/tcp/udp/ws` 首版。
- 平台插件：clipboard/hotkey/notification 首版。
- 全量 feature flag 校验与裁剪报告。

### M4：发布准备（1~2 周）

- 文档站点与插件开发指南。
- 基准测试（吞吐、延迟、内存占用）。
- 稳定版 API 清单与版本策略（SemVer）。

---

## 9. 验收指标（建议）

- 功能：核心插件加载成功率 100%，Lua 管理 API 可用。
- 安全：敏感能力 100% 权限门控覆盖。
- 性能：高频调用路径无明显锁争用；权限缓存命中率可观测。
- 稳定性：插件异常不拖垮 Runtime（故障隔离）。
- 工程性：新增插件可在 1 天内完成从接入到测试闭环。
