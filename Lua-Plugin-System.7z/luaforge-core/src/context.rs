use std::sync::Arc;

use mlua::Lua;

use crate::permission::PermissionGate;
use crate::resource::ResourceManager;

/// 运行时共享上下文。
///
/// 这是插件体系的“公共依赖注入容器”，目前承载：
/// - 权限网关（安全治理）
/// - 资源管理器（长生命周期对象治理）
///
/// 未来也可继续挂载：
/// - 统一异步 runtime 句柄
/// - 事件总线
/// - 监控/指标采集器
#[derive(Clone)]
pub struct ForgeContext {
    pub permissions: Arc<PermissionGate>,
    pub resources: Arc<ResourceManager>,
}

impl ForgeContext {
    /// 构造上下文。
    pub fn new(permissions: Arc<PermissionGate>, resources: Arc<ResourceManager>) -> Self {
        Self {
            permissions,
            resources,
        }
    }
}

impl std::fmt::Debug for ForgeContext {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("ForgeContext")
            .field("permissions", &self.permissions)
            .field("resources", &self.resources)
            .finish()
    }
}

/// 把上下文写入 Lua 的 `app_data`。
///
/// 这样在任意 Lua 回调中都可以反向取回上下文，避免层层传参。
pub fn set_forge_context(lua: &Lua, ctx: ForgeContext) {
    let _ = lua.set_app_data(ctx);
}

/// 尝试读取上下文，不存在则返回 `None`。
pub fn try_get_forge_context(lua: &Lua) -> Option<ForgeContext> {
    lua.app_data_ref::<ForgeContext>().map(|ctx| ctx.clone())
}

/// 获取上下文，不存在则 panic。
///
/// 用于框架内部“必须存在上下文”的路径（例如注册中心 Lua API）。
pub fn get_forge_context(lua: &Lua) -> ForgeContext {
    try_get_forge_context(lua)
        .expect("ForgeContext must be set in Lua app_data before using registry API")
}
