use thiserror::Error;

pub type ForgeResult<T> = Result<T, ForgeError>;

#[derive(Debug, Error)]
pub enum ForgeError {
    #[error("lua error: {0}")]
    Lua(#[from] mlua::Error),

    #[error("permission denied: {permission}")]
    PermissionDenied { permission: String },

    #[error("plugin error [{plugin_id}]: {message}")]
    Plugin { plugin_id: String, message: String },

    #[error("plugin not found: {plugin_id}")]
    PluginNotFound { plugin_id: String },

    #[error("plugin already loaded: {plugin_id}")]
    PluginAlreadyLoaded { plugin_id: String },

    #[error("cannot unload builtin plugin: {plugin_id}")]
    CannotUnloadBuiltin { plugin_id: String },

    #[error("missing dependency for plugin '{plugin_id}': {dependency}")]
    MissingDependency {
        plugin_id: String,
        dependency: String,
    },

    #[error("resource error: {0}")]
    Resource(String),

    #[error("resource pool exhausted: type={type_tag}, max={max}")]
    PoolExhausted { type_tag: String, max: usize },

    #[error("resource handle not found: id={id}, type={type_tag}")]
    HandleNotFound { id: u64, type_tag: String },

    #[error("serialization error: {0}")]
    Serialize(String),

    #[error("io error: {0}")]
    Io(#[from] std::io::Error),

    #[error("{0}")]
    Custom(String),
}

impl ForgeError {
    pub fn custom(msg: impl Into<String>) -> Self {
        Self::Custom(msg.into())
    }

    pub fn plugin(plugin_id: impl Into<String>, message: impl Into<String>) -> Self {
        Self::Plugin {
            plugin_id: plugin_id.into(),
            message: message.into(),
        }
    }
}

impl From<ForgeError> for mlua::Error {
    fn from(value: ForgeError) -> Self {
        mlua::Error::RuntimeError(value.to_string())
    }
}
