use std::collections::HashMap;

use bytes::Bytes;
use mlua::{Lua, LuaSerdeExt, UserData, UserDataMethods, Value};

use crate::error::ForgeResult;

#[derive(Debug, Clone)]
pub struct LuaBuffer {
    inner: Bytes,
}

impl LuaBuffer {
    pub fn new(data: impl Into<Bytes>) -> Self {
        Self { inner: data.into() }
    }

    pub fn len(&self) -> usize {
        self.inner.len()
    }

    pub fn is_empty(&self) -> bool {
        self.inner.is_empty()
    }

    pub fn as_slice(&self) -> &[u8] {
        &self.inner
    }
}

impl UserData for LuaBuffer {
    fn add_methods<M: UserDataMethods<Self>>(methods: &mut M) {
        methods.add_method("len", |_lua, this, ()| Ok(this.len()));
        methods.add_method("is_empty", |_lua, this, ()| Ok(this.is_empty()));
        methods.add_method("to_string", |_lua, this, ()| {
            Ok(String::from_utf8_lossy(this.as_slice()).into_owned())
        });
    }
}

pub trait IntoLuaForge {
    fn into_lua_forge(self, lua: &Lua) -> ForgeResult<Value>;
}

pub trait FromLuaForge: Sized {
    fn from_lua_forge(lua: &Lua, value: Value) -> ForgeResult<Self>;
}

impl IntoLuaForge for serde_json::Value {
    fn into_lua_forge(self, lua: &Lua) -> ForgeResult<Value> {
        Ok(lua.to_value(&self)?)
    }
}

impl FromLuaForge for serde_json::Value {
    fn from_lua_forge(lua: &Lua, value: Value) -> ForgeResult<Self> {
        Ok(lua.from_value(value)?)
    }
}

impl IntoLuaForge for HashMap<String, serde_json::Value> {
    fn into_lua_forge(self, lua: &Lua) -> ForgeResult<Value> {
        Ok(lua.to_value(&self)?)
    }
}

impl IntoLuaForge for Vec<u8> {
    fn into_lua_forge(self, lua: &Lua) -> ForgeResult<Value> {
        Ok(Value::String(lua.create_string(&self)?))
    }
}

impl IntoLuaForge for String {
    fn into_lua_forge(self, lua: &Lua) -> ForgeResult<Value> {
        Ok(Value::String(lua.create_string(&self)?))
    }
}

pub fn lua_value_to_json(lua: &Lua, value: Value) -> ForgeResult<serde_json::Value> {
    Ok(lua.from_value(value)?)
}

pub fn json_to_lua_value(lua: &Lua, value: &serde_json::Value) -> ForgeResult<Value> {
    Ok(lua.to_value(value)?)
}
