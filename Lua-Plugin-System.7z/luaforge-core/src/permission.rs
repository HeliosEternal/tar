use std::borrow::Cow;
use std::collections::HashMap;
use std::fmt;
use std::sync::Arc;

use dashmap::DashSet;
use parking_lot::RwLock;

use crate::error::{ForgeError, ForgeResult};

/// 权限标识符，采用点分层级（例如 `fs.read`、`net.http.request`）。
///
/// 采用 `Cow<'static, str>` 的原因：
/// - 静态权限可零分配使用（`new_static`）；
/// - 动态权限仍可安全存储（`new`）。
#[derive(Clone, Debug, Hash, Eq, PartialEq)]
pub struct Permission(Cow<'static, str>);

impl Permission {
    /// 创建静态权限，适合声明成常量数组。
    pub const fn new_static(value: &'static str) -> Self {
        Self(Cow::Borrowed(value))
    }

    /// 创建动态权限。
    pub fn new(value: impl Into<String>) -> Self {
        Self(Cow::Owned(value.into()))
    }

    /// 获取权限字符串。
    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl fmt::Display for Permission {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.0)
    }
}

impl From<&'static str> for Permission {
    fn from(value: &'static str) -> Self {
        Permission::new_static(value)
    }
}

impl From<String> for Permission {
    fn from(value: String) -> Self {
        Permission::new(value)
    }
}

/// 权限判定等级。
///
/// - `Open`：允许直接调用。
/// - `Prompt`：首次询问并缓存结果。
/// - `AlwaysAsk`：每次都询问，不缓存。
/// - `Deny`：直接拒绝。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PermissionLevel {
    Open,
    Prompt,
    AlwaysAsk,
    Deny,
}

/// 权限策略表。
///
/// 规则支持：
/// 1. 精确匹配（`fs.read`）；
/// 2. 前缀匹配（`fs` 可匹配 `fs.read` / `fs.write`）；
/// 3. 默认策略兜底。
#[derive(Debug, Clone)]
pub struct PermissionPolicy {
    rules: HashMap<String, PermissionLevel>,
    default: PermissionLevel,
}

impl PermissionPolicy {
    pub fn new(default: PermissionLevel) -> Self {
        Self {
            rules: HashMap::new(),
            default,
        }
    }

    /// 添加/覆盖一条策略规则。
    pub fn add_rule(&mut self, permission: impl Into<Permission>, level: PermissionLevel) {
        self.rules.insert(permission.into().to_string(), level);
    }

    /// 解析某个权限应应用的最终策略。
    ///
    /// 优先级：
    /// 1. 精确命中；
    /// 2. 最长前缀命中；
    /// 3. 默认策略。
    pub fn resolve(&self, permission: &Permission) -> PermissionLevel {
        let target = permission.as_str();

        if let Some(level) = self.rules.get(target).copied() {
            return level;
        }

        let mut best: Option<(usize, PermissionLevel)> = None;
        for (key, level) in &self.rules {
            let is_prefix_match = target == key
                || (target.starts_with(key)
                    && target.as_bytes().get(key.len()).copied() == Some(b'.'));
            if !is_prefix_match {
                continue;
            }

            let len = key.len();
            if best.map(|(best_len, _)| len > best_len).unwrap_or(true) {
                best = Some((len, *level));
            }
        }

        best.map(|(_, level)| level).unwrap_or(self.default)
    }

    /// 返回默认策略。
    pub fn default_level(&self) -> PermissionLevel {
        self.default
    }
}

/// 权限提示回调。
///
/// 宿主应用可注入自己的实现，例如：
/// - 弹窗询问用户；
/// - 从远端策略中心获取决策；
/// - 在 CI/测试环境统一允许或拒绝。
pub trait PermissionPromptHandler: Send + Sync + 'static {
    /// 返回 `true` 表示允许，`false` 表示拒绝。
    fn prompt(&self, permission: &Permission, action: &str) -> bool;
}

/// 测试/开发用：全部允许。
#[derive(Debug, Default)]
pub struct AllowAllPromptHandler;

impl PermissionPromptHandler for AllowAllPromptHandler {
    fn prompt(&self, _permission: &Permission, _action: &str) -> bool {
        true
    }
}

/// 测试/沙箱用：全部拒绝。
#[derive(Debug, Default)]
pub struct DenyAllPromptHandler;

impl PermissionPromptHandler for DenyAllPromptHandler {
    fn prompt(&self, _permission: &Permission, _action: &str) -> bool {
        false
    }
}

/// 权限网关，负责把“策略”应用到每次敏感调用。
///
/// 关键点：
/// - `policy` 可热更新（`RwLock`）；
/// - `granted` 用于 `Prompt` 模式缓存授权结果；
/// - `prompt_handler` 决定交互方式。
pub struct PermissionGate {
    policy: Arc<RwLock<PermissionPolicy>>,
    granted: DashSet<String>,
    prompt_handler: Arc<dyn PermissionPromptHandler>,
}

impl PermissionGate {
    /// 使用具体回调类型创建网关。
    pub fn new(policy: PermissionPolicy, prompt_handler: impl PermissionPromptHandler) -> Self {
        Self::with_handler(policy, Arc::new(prompt_handler))
    }

    /// 使用 trait object 回调创建网关（适合运行时动态注入）。
    pub fn with_handler(
        policy: PermissionPolicy,
        prompt_handler: Arc<dyn PermissionPromptHandler>,
    ) -> Self {
        Self {
            policy: Arc::new(RwLock::new(policy)),
            granted: DashSet::new(),
            prompt_handler,
        }
    }

    /// 核心检查逻辑。
    ///
    /// 调用方只需要传入：
    /// - 权限名（如 `fs.write`）
    /// - 动作描述（如 `forge.fs::write_text`）
    ///
    /// 返回 `Ok(())` 表示允许执行，返回错误则应终止本次调用。
    pub fn check(&self, permission: &Permission, action: &str) -> ForgeResult<()> {
        match self.level(permission) {
            PermissionLevel::Open => Ok(()),
            PermissionLevel::Deny => Err(ForgeError::PermissionDenied {
                permission: permission.to_string(),
            }),
            PermissionLevel::Prompt => {
                if self.granted.contains(permission.as_str()) {
                    return Ok(());
                }

                if self.prompt_handler.prompt(permission, action) {
                    self.granted.insert(permission.to_string());
                    Ok(())
                } else {
                    Err(ForgeError::PermissionDenied {
                        permission: permission.to_string(),
                    })
                }
            }
            PermissionLevel::AlwaysAsk => {
                if self.prompt_handler.prompt(permission, action) {
                    Ok(())
                } else {
                    Err(ForgeError::PermissionDenied {
                        permission: permission.to_string(),
                    })
                }
            }
        }
    }

    /// 获取某个权限的当前策略等级。
    pub fn level(&self, permission: &Permission) -> PermissionLevel {
        self.policy.read().resolve(permission)
    }

    /// 手动授予权限（直接写入缓存）。
    pub fn grant(&self, permission: impl Into<Permission>) {
        self.granted.insert(permission.into().to_string());
    }

    /// 撤销已缓存授权。
    pub fn revoke(&self, permission: impl Into<Permission>) {
        let permission: Permission = permission.into();
        self.granted.remove(permission.as_str());
    }

    /// 清空授权缓存（不修改策略本身）。
    pub fn clear_cache(&self) {
        self.granted.clear();
    }

    /// 整体替换策略并清空缓存，避免旧决策污染新策略。
    pub fn update_policy(&self, policy: PermissionPolicy) {
        *self.policy.write() = policy;
        self.clear_cache();
    }

    /// 获取策略快照。
    pub fn policy(&self) -> PermissionPolicy {
        self.policy.read().clone()
    }
}

impl fmt::Debug for PermissionGate {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("PermissionGate")
            .field("policy", &self.policy.read())
            .field("granted_count", &self.granted.len())
            .finish()
    }
}
