use std::time::Instant;

use serde::Serialize;

use crate::context::ForgeContext;
use crate::error::ForgeResult;
use crate::permission::Permission;
use crate::registrar::LuaRegistrar;

/// 插件类型。
///
/// - `Builtin`：随系统启动加载，默认认为是核心能力，不允许随意卸载。
/// - `User`：业务或第三方扩展，可按需加载/卸载/暂停。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
pub enum PluginKind {
    Builtin,
    User,
}

impl PluginKind {
    pub fn as_str(self) -> &'static str {
        match self {
            PluginKind::Builtin => "builtin",
            PluginKind::User => "user",
        }
    }
}

/// 健康状态（当前主要用于扩展接口预留）。
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PluginHealth {
    Healthy,
    Degraded,
    Unhealthy,
}

/// 插件运行状态。
///
/// 说明：
/// - `Active`：正常可用。
/// - `Suspended`：被运维/系统临时停用，保留元数据。
/// - `Error`：插件进入错误态，字符串保存错误原因。
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub enum PluginState {
    Active,
    Suspended,
    Error(String),
}

impl PluginState {
    pub fn as_str(&self) -> &'static str {
        match self {
            PluginState::Active => "active",
            PluginState::Suspended => "suspended",
            PluginState::Error(_) => "error",
        }
    }
}

/// 插件统计信息。
///
/// 当前字段已预留，后续可在注册器或调用链统一埋点更新。
#[derive(Debug, Clone, Serialize, Default)]
pub struct PluginStats {
    /// 成功或失败总调用次数。
    pub call_count: u64,
    /// 失败次数。
    pub error_count: u64,
    /// 平均耗时（毫秒）。
    pub avg_latency_ms: u64,
}

/// 提供给 Lua 管理接口或宿主 UI 的插件快照信息。
#[derive(Debug, Clone, Serialize)]
pub struct PluginInfo {
    pub id: String,
    pub name: String,
    pub version: String,
    pub kind: PluginKind,
    pub state: PluginState,
    pub loaded_at_ms: u128,
    pub stats: PluginStats,
}

/// 所有插件必须实现的核心协议。
///
/// 这个 trait 是 LuaForge 的“扩展点基座”：
/// - 通过 `id/name/version` 描述插件身份；
/// - 通过 `required_permissions/dependencies` 描述安全与依赖约束；
/// - 通过 `register` 完成 Lua API 暴露；
/// - 通过 `on_unload` 完成资源清理。
pub trait ForgePlugin: Send + Sync + 'static {
    /// 全局唯一 ID，推荐命名：`forge.<domain>[.<subdomain>]`。
    fn id(&self) -> &'static str;
    /// 人类可读名称，用于 UI 展示与日志输出。
    fn name(&self) -> &'static str;
    /// 插件版本（建议语义化版本）。
    fn version(&self) -> &'static str;

    /// 插件类型，默认按用户插件处理。
    fn kind(&self) -> PluginKind {
        PluginKind::User
    }

    /// 插件声明的权限集合。
    ///
    /// 这里是“静态声明”，用于加载阶段快速校验和审计。
    fn required_permissions(&self) -> &[Permission] {
        &[]
    }

    /// 依赖的其它插件 id 列表。
    ///
    /// 注册中心会在加载前检查依赖是否已满足。
    fn dependencies(&self) -> &[&'static str] {
        &[]
    }

    /// 插件的核心注册函数。
    ///
    /// 典型操作：
    /// 1. `reg.add_function` 注册普通 API；
    /// 2. `reg.add_guarded_function` 注册敏感 API；
    /// 3. `reg.add_submodule` 拆分子命名空间。
    fn register(&self, registrar: &mut LuaRegistrar<'_>, ctx: &ForgeContext) -> ForgeResult<()>;

    /// 插件卸载前回调，用于释放外部资源（连接、句柄、线程等）。
    fn on_unload(&self, _ctx: &ForgeContext) -> ForgeResult<()> {
        Ok(())
    }

    /// 健康检查钩子，便于未来接入巡检/监控系统。
    fn health_check(&self) -> PluginHealth {
        PluginHealth::Healthy
    }
}

/// 把内部 `PluginEntry` 信息转换成可序列化的 `PluginInfo`。
pub(crate) fn plugin_info_from_entry(
    id: &str,
    name: &str,
    version: &str,
    kind: PluginKind,
    state: PluginState,
    loaded_at: Instant,
    stats: PluginStats,
) -> PluginInfo {
    PluginInfo {
        id: id.to_string(),
        name: name.to_string(),
        version: version.to_string(),
        kind,
        state,
        loaded_at_ms: loaded_at.elapsed().as_millis(),
        stats,
    }
}
