use mlua::{FromLuaMulti, IntoLua, IntoLuaMulti, Lua, Table};

use crate::context::ForgeContext;
use crate::error::ForgeResult;
use crate::permission::Permission;

/// `LuaRegistrar` 是插件向 Lua 侧“挂载能力”的统一入口。
///
/// 设计目的：
/// 1. 隐藏 `mlua` 的样板代码，插件开发者只关心函数语义，不关心表创建细节。
/// 2. 强制通过命名空间组织 API，避免污染 Lua 全局环境。
/// 3. 与 `ForgeContext` 绑定，使注册阶段可以直接接入权限网关与资源管理器。
///
/// 例如插件 id 为 `forge.fs` 时，注册的函数最终会出现在：
/// `forge.fs.read_text(...)`、`forge.fs.write_text(...)`。
pub struct LuaRegistrar<'lua> {
    /// 当前绑定的 Lua VM。
    lua: &'lua Lua,
    /// 命名空间路径（如 `forge.fs`、`forge.net.http`）。
    namespace: String,
    /// 命名空间对应的 Lua table。
    table: Table,
    /// 运行时共享上下文（权限/资源等）。
    ctx: ForgeContext,
}

impl<'lua> LuaRegistrar<'lua> {
    /// 创建注册器，并确保命名空间 table 已存在。
    ///
    /// 如果路径中某一层不存在（例如 `forge` 或 `forge.fs`），会自动创建。
    pub fn new(
        lua: &'lua Lua,
        namespace: impl Into<String>,
        ctx: ForgeContext,
    ) -> ForgeResult<Self> {
        let namespace = namespace.into();
        let table = ensure_namespace_table(lua, &namespace)?;
        Ok(Self {
            lua,
            namespace,
            table,
            ctx,
        })
    }

    /// 返回当前注册器绑定的命名空间字符串。
    pub fn namespace(&self) -> &str {
        &self.namespace
    }

    /// 返回共享上下文，供插件在注册时读取运行时能力。
    pub fn context(&self) -> &ForgeContext {
        &self.ctx
    }

    /// 注册普通函数（无权限拦截）。
    ///
    /// 适用于纯计算、纯转换等低风险 API。
    pub fn add_function<A, R, F>(&self, name: &str, func: F) -> ForgeResult<()>
    where
        A: FromLuaMulti,
        R: IntoLuaMulti,
        F: Fn(&Lua, A) -> mlua::Result<R> + Send + 'static,
    {
        let function = self.lua.create_function(func)?;
        self.table.set(name, function)?;
        Ok(())
    }

    /// 注册带权限保护的函数。
    ///
    /// 调用路径：
    /// Lua 调用 -> 包装闭包 -> PermissionGate::check -> 真正业务函数。
    ///
    /// 这样做的好处是：
    /// - 插件作者无需在每个函数体内手写权限判断。
    /// - 权限策略与业务逻辑分离，便于统一治理和审计。
    pub fn add_guarded_function<A, R, F>(
        &self,
        name: &str,
        permission: impl Into<Permission>,
        func: F,
    ) -> ForgeResult<()>
    where
        A: FromLuaMulti,
        R: IntoLuaMulti,
        F: Fn(&Lua, A) -> mlua::Result<R> + Send + 'static,
    {
        let gate = self.ctx.permissions.clone();
        let permission = permission.into();
        let action = format!("{}::{}", self.namespace, name);

        let function = self.lua.create_function(move |lua, args: A| {
            gate.check(&permission, &action)
                .map_err(mlua::Error::from)?;
            func(lua, args)
        })?;
        self.table.set(name, function)?;
        Ok(())
    }

    /// 在命名空间下挂载常量值。
    ///
    /// 例如：
    /// `forge.sys.VERSION = "0.1.0"`
    pub fn add_constant<T>(&self, name: &str, value: T) -> ForgeResult<()>
    where
        T: IntoLua,
    {
        self.table.set(name, value)?;
        Ok(())
    }

    /// 创建子模块注册器。
    ///
    /// 例：当前是 `forge.net`，调用 `add_submodule("http")` 后返回 `forge.net.http`。
    pub fn add_submodule(&self, name: &str) -> ForgeResult<LuaRegistrar<'lua>> {
        let namespace = format!("{}.{}", self.namespace, name);
        LuaRegistrar::new(self.lua, namespace, self.ctx.clone())
    }

    /// 暴露底层 Lua 引用，供少数高级场景直接使用 `mlua` 原生能力。
    pub fn lua(&self) -> &'lua Lua {
        self.lua
    }
}

/// 根据插件 id 创建注册器。
///
/// 这里单独提供函数是为了把“插件 id 即命名空间”的约定固化在一处，
/// 避免各处手写字符串带来不一致。
pub fn create_registrar_for_plugin<'lua>(
    lua: &'lua Lua,
    plugin_id: &str,
    ctx: ForgeContext,
) -> ForgeResult<LuaRegistrar<'lua>> {
    LuaRegistrar::new(lua, plugin_id, ctx)
}

/// 从 Lua 全局表中移除命名空间入口。
///
/// 注意：这是“逻辑卸载”，仅移除可访问入口；
/// 已经被 Lua 侧保存到局部变量的函数引用不会自动失效。
pub fn remove_namespace_table(lua: &Lua, namespace: &str) -> mlua::Result<()> {
    let parts: Vec<&str> = namespace.split('.').collect();
    if parts.is_empty() {
        return Ok(());
    }

    let mut current = lua.globals();
    for part in &parts[..parts.len().saturating_sub(1)] {
        let Some(table) = current.get::<Option<Table>>(*part)? else {
            return Ok(());
        };
        current = table;
    }

    if let Some(last) = parts.last() {
        current.set(*last, mlua::Value::Nil)?;
    }

    Ok(())
}

/// 确保命名空间对应的 table 已存在，若不存在则逐层创建。
///
/// 示例：
/// - 输入 `forge.net.http`
/// - 自动保证 `forge`、`forge.net`、`forge.net.http` 都可访问。
fn ensure_namespace_table(lua: &Lua, namespace: &str) -> mlua::Result<Table> {
    let mut current = lua.globals();

    for part in namespace.split('.') {
        let next = match current.get::<Option<Table>>(part)? {
            Some(existing) => existing,
            None => {
                let created = lua.create_table()?;
                current.set(part, created.clone())?;
                created
            }
        };
        current = next;
    }

    Ok(current)
}
