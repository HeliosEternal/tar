use std::collections::HashMap;
use std::sync::Arc;
use std::time::Instant;

use indexmap::IndexMap;
use mlua::{Lua, Table, Value};
use parking_lot::RwLock;

use crate::context::{get_forge_context, ForgeContext};
use crate::error::{ForgeError, ForgeResult};
use crate::permission::PermissionLevel;
use crate::plugin::{plugin_info_from_entry, ForgePlugin, PluginInfo, PluginState, PluginStats};
use crate::registrar::{create_registrar_for_plugin, remove_namespace_table, LuaRegistrar};

/// 插件工厂函数签名。
///
/// 通过工厂而不是直接保存实例的原因：
/// - 支持 `forge.plugins.load("id")` 这种按 id 延迟创建；
/// - 避免实例在未加载前占用资源。
type PluginFactory = Arc<dyn Fn() -> Arc<dyn ForgePlugin> + Send + Sync>;

/// 注册中心内部条目，不直接对外暴露。
///
/// 对外暴露时会被转换为可序列化 `PluginInfo`。
struct PluginEntry {
    plugin: Arc<dyn ForgePlugin>,
    state: PluginState,
    loaded_at: Instant,
    stats: PluginStats,
}

impl PluginEntry {
    fn new(plugin: Arc<dyn ForgePlugin>) -> Self {
        Self {
            plugin,
            state: PluginState::Active,
            loaded_at: Instant::now(),
            stats: PluginStats::default(),
        }
    }

    fn info(&self) -> PluginInfo {
        plugin_info_from_entry(
            self.plugin.id(),
            self.plugin.name(),
            self.plugin.version(),
            self.plugin.kind(),
            self.state.clone(),
            self.loaded_at,
            self.stats.clone(),
        )
    }
}

/// 插件注册中心。
///
/// 它是整个运行时中插件生命周期的“单一事实来源”：
/// - 负责加载、卸载、挂起、恢复；
/// - 负责依赖检查、权限前置检查；
/// - 负责向 Lua 暴露 `forge.plugins.*` 管理接口。
pub struct PluginRegistry {
    /// 当前已加载插件集合，保留插入顺序。
    plugins: RwLock<IndexMap<String, PluginEntry>>,
    /// 加载顺序快照，便于未来实现依赖逆序卸载等策略。
    load_order: RwLock<Vec<String>>,
    /// 可按 id 动态创建插件的工厂表。
    factories: RwLock<HashMap<String, PluginFactory>>,
}

impl PluginRegistry {
    /// 创建空注册中心。
    pub fn new() -> Self {
        Self {
            plugins: RwLock::new(IndexMap::new()),
            load_order: RwLock::new(Vec::new()),
            factories: RwLock::new(HashMap::new()),
        }
    }

    /// 注册插件工厂（通常在 runtime 启动时由内置插件包调用）。
    pub fn register_factory<F>(&self, plugin_id: &str, factory: F)
    where
        F: Fn() -> Arc<dyn ForgePlugin> + Send + Sync + 'static,
    {
        self.factories
            .write()
            .insert(plugin_id.to_string(), Arc::new(factory));
    }

    /// 按 id 通过工厂加载插件。
    ///
    /// 常用于 Lua 侧动态加载：`forge.plugins.load("forge.xxx")`。
    pub fn load_by_id(&self, plugin_id: &str, lua: &Lua, ctx: &ForgeContext) -> ForgeResult<()> {
        let factory = self
            .factories
            .read()
            .get(plugin_id)
            .cloned()
            .ok_or_else(|| ForgeError::PluginNotFound {
                plugin_id: plugin_id.to_string(),
            })?;

        self.load_arc(factory(), lua, ctx)
    }

    /// 加载具体插件实例（便于宿主直接传入实现类型）。
    pub fn load(&self, plugin: impl ForgePlugin, lua: &Lua, ctx: &ForgeContext) -> ForgeResult<()> {
        self.load_arc(Arc::new(plugin), lua, ctx)
    }

    /// 加载 `Arc<dyn ForgePlugin>` 的统一实现。
    ///
    /// 核心流程：
    /// 1. 去重检查；
    /// 2. 依赖检查；
    /// 3. 权限声明前置检查；
    /// 4. 调用插件 `register` 挂载 Lua API；
    /// 5. 记录到注册中心。
    pub fn load_arc(
        &self,
        plugin: Arc<dyn ForgePlugin>,
        lua: &Lua,
        ctx: &ForgeContext,
    ) -> ForgeResult<()> {
        let plugin_id = plugin.id().to_string();

        {
            let plugins = self.plugins.read();
            if plugins.contains_key(&plugin_id) {
                return Err(ForgeError::PluginAlreadyLoaded { plugin_id });
            }

            for dep in plugin.dependencies() {
                if !plugins.contains_key(*dep) {
                    return Err(ForgeError::MissingDependency {
                        plugin_id: plugin.id().to_string(),
                        dependency: (*dep).to_string(),
                    });
                }
            }
        }

        for permission in plugin.required_permissions() {
            if ctx.permissions.level(permission) == PermissionLevel::Deny {
                return Err(ForgeError::PermissionDenied {
                    permission: permission.to_string(),
                });
            }
        }

        let mut registrar = create_registrar_for_plugin(lua, plugin.id(), ctx.clone())?;
        plugin.register(&mut registrar, ctx)?;

        self.plugins
            .write()
            .insert(plugin_id.clone(), PluginEntry::new(plugin));
        self.load_order.write().push(plugin_id);
        Ok(())
    }

    /// 卸载插件。
    ///
    /// 当前策略：
    /// - 内置插件禁止卸载；
    /// - 卸载时调用 `on_unload` 做资源清理；
    /// - 从 Lua 全局命名空间移除入口表。
    pub fn unload(&self, id: &str, lua: &Lua, ctx: &ForgeContext) -> ForgeResult<()> {
        {
            let plugins = self.plugins.read();
            let Some(entry) = plugins.get(id) else {
                return Err(ForgeError::PluginNotFound {
                    plugin_id: id.to_string(),
                });
            };
            if entry.plugin.kind().as_str() == "builtin" {
                return Err(ForgeError::CannotUnloadBuiltin {
                    plugin_id: id.to_string(),
                });
            }
        }

        let removed =
            self.plugins
                .write()
                .shift_remove(id)
                .ok_or_else(|| ForgeError::PluginNotFound {
                    plugin_id: id.to_string(),
                })?;

        removed.plugin.on_unload(ctx)?;
        remove_namespace_table(lua, id)?;
        self.load_order.write().retain(|p| p != id);
        Ok(())
    }

    /// 挂起插件（标记状态，不做表级移除）。
    pub fn suspend(&self, id: &str) -> ForgeResult<()> {
        let mut plugins = self.plugins.write();
        let entry = plugins
            .get_mut(id)
            .ok_or_else(|| ForgeError::PluginNotFound {
                plugin_id: id.to_string(),
            })?;
        entry.state = PluginState::Suspended;
        Ok(())
    }

    /// 恢复被挂起插件。
    pub fn resume(&self, id: &str) -> ForgeResult<()> {
        let mut plugins = self.plugins.write();
        let entry = plugins
            .get_mut(id)
            .ok_or_else(|| ForgeError::PluginNotFound {
                plugin_id: id.to_string(),
            })?;
        entry.state = PluginState::Active;
        Ok(())
    }

    /// 获取插件快照列表。
    pub fn list(&self) -> Vec<PluginInfo> {
        self.plugins
            .read()
            .values()
            .map(PluginEntry::info)
            .collect::<Vec<_>>()
    }

    /// 获取指定插件快照。
    pub fn get(&self, id: &str) -> Option<PluginInfo> {
        self.plugins.read().get(id).map(|entry| entry.info())
    }

    /// 判断插件是否处于激活态。
    pub fn is_active(&self, id: &str) -> bool {
        self.plugins
            .read()
            .get(id)
            .map(|entry| entry.state == PluginState::Active)
            .unwrap_or(false)
    }

    /// 已加载插件数量。
    pub fn count(&self) -> usize {
        self.plugins.read().len()
    }

    /// 向 Lua 注册插件管理接口（`forge.plugins.*`）。
    ///
    /// 注册完成后，Lua 脚本可直接查询和控制插件生命周期。
    pub fn register_lua_api(registry: Arc<PluginRegistry>, lua: &Lua) -> ForgeResult<()> {
        let ctx = get_forge_context(lua);
        let reg = LuaRegistrar::new(lua, "forge.plugins", ctx)?;

        {
            let registry = registry.clone();
            reg.add_function("list", move |lua, ()| {
                let list = registry.list();
                plugin_info_list_to_table(lua, &list)
            })?;
        }

        {
            let registry = registry.clone();
            reg.add_function("info", move |lua, id: String| match registry.get(&id) {
                Some(info) => Ok(Value::Table(plugin_info_to_table(lua, &info)?)),
                None => Ok(Value::Nil),
            })?;
        }

        {
            let registry = registry.clone();
            reg.add_function("load", move |lua, id: String| {
                let ctx = get_forge_context(lua);
                registry
                    .load_by_id(&id, lua, &ctx)
                    .map_err(mlua::Error::from)
            })?;
        }

        {
            let registry = registry.clone();
            reg.add_function("unload", move |lua, id: String| {
                let ctx = get_forge_context(lua);
                registry.unload(&id, lua, &ctx).map_err(mlua::Error::from)
            })?;
        }

        {
            let registry = registry.clone();
            reg.add_function("suspend", move |_lua, id: String| {
                registry.suspend(&id).map_err(mlua::Error::from)
            })?;
        }

        {
            let registry = registry.clone();
            reg.add_function("resume", move |_lua, id: String| {
                registry.resume(&id).map_err(mlua::Error::from)
            })?;
        }

        Ok(())
    }
}

impl Default for PluginRegistry {
    fn default() -> Self {
        Self::new()
    }
}

impl std::fmt::Debug for PluginRegistry {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("PluginRegistry")
            .field("plugin_count", &self.count())
            .finish()
    }
}

/// 把插件列表转成 Lua 数组 table（1-based 索引）。
fn plugin_info_list_to_table(lua: &Lua, infos: &[PluginInfo]) -> mlua::Result<Table> {
    let table = lua.create_table()?;
    for (idx, info) in infos.iter().enumerate() {
        table.raw_set(idx + 1, plugin_info_to_table(lua, info)?)?;
    }
    Ok(table)
}

/// 把单个 `PluginInfo` 转成 Lua table。
fn plugin_info_to_table(lua: &Lua, info: &PluginInfo) -> mlua::Result<Table> {
    let table = lua.create_table()?;
    table.set("id", info.id.clone())?;
    table.set("name", info.name.clone())?;
    table.set("version", info.version.clone())?;
    table.set("kind", info.kind.as_str())?;
    table.set("state", info.state.as_str())?;
    table.set("loaded_at_ms", info.loaded_at_ms as i64)?;

    let stats = lua.create_table()?;
    stats.set("call_count", info.stats.call_count as i64)?;
    stats.set("error_count", info.stats.error_count as i64)?;
    stats.set("avg_latency_ms", info.stats.avg_latency_ms as i64)?;
    table.set("stats", stats)?;

    if let PluginState::Error(msg) = &info.state {
        table.set("error", msg.clone())?;
    }

    Ok(table)
}
