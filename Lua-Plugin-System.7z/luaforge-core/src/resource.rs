use std::any::Any;
use std::fmt;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;

use dashmap::DashMap;

use crate::error::{ForgeError, ForgeResult};

/// 资源池配置。
///
/// 当前只限制“每种类型最多注册多少个资源”，
/// 后续可以扩展总内存上限、空闲回收策略等。
#[derive(Debug, Clone)]
pub struct PoolConfig {
    /// 同一 `type_tag` 允许存在的最大资源数。
    pub max_resources_per_type: usize,
}

impl Default for PoolConfig {
    fn default() -> Self {
        Self {
            max_resources_per_type: 512,
        }
    }
}

/// 资源句柄（对 Lua 或插件暴露的轻量引用）。
///
/// 设计上避免直接暴露真实资源对象，统一通过句柄访问，
/// 便于做配额、审计、回收和权限控制。
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct ResourceHandle {
    /// 全局唯一 id，由 `AtomicU64` 递增分配。
    pub id: u64,
    /// 类型标签，用于运行时校验与统计（如 `tcp.stream`）。
    pub type_tag: String,
}

/// 内部存储单元，包含真实资源和类型标签。
struct StoredResource {
    type_tag: String,
    value: Arc<dyn Any + Send + Sync>,
}

/// 资源管理器：负责长生命周期对象的统一托管。
///
/// 典型托管对象：
/// - 网络连接（TCP/UDP/WebSocket）
/// - 客户端实例（HTTP client）
/// - 系统句柄（文件监听器、平台对象）
pub struct ResourceManager {
    /// 下一个可分配句柄 id。
    next_id: AtomicU64,
    /// id -> 资源实体。
    resources: DashMap<u64, StoredResource>,
    /// type_tag -> 数量，用于快速做配额判断。
    type_counts: DashMap<String, usize>,
    /// 池配置。
    limits: PoolConfig,
}

impl ResourceManager {
    /// 用指定配额创建资源管理器。
    pub fn new(limits: PoolConfig) -> Self {
        Self {
            next_id: AtomicU64::new(1),
            resources: DashMap::new(),
            type_counts: DashMap::new(),
            limits,
        }
    }

    /// 用默认配额创建。
    pub fn with_defaults() -> Self {
        Self::new(PoolConfig::default())
    }

    /// 注册资源并返回句柄。
    ///
    /// 步骤：
    /// 1. 校验类型配额；
    /// 2. 分配新 id；
    /// 3. 写入资源表与类型计数；
    /// 4. 返回可序列化句柄。
    pub fn insert<T>(&self, type_tag: impl Into<String>, resource: T) -> ForgeResult<ResourceHandle>
    where
        T: Any + Send + Sync + 'static,
    {
        let type_tag = type_tag.into();
        let current = self.type_counts.get(&type_tag).map(|v| *v).unwrap_or(0);
        if current >= self.limits.max_resources_per_type {
            return Err(ForgeError::PoolExhausted {
                type_tag,
                max: self.limits.max_resources_per_type,
            });
        }

        let id = self.next_id.fetch_add(1, Ordering::Relaxed);
        let handle = ResourceHandle {
            id,
            type_tag: type_tag.clone(),
        };

        self.resources.insert(
            id,
            StoredResource {
                type_tag: type_tag.clone(),
                value: Arc::new(resource),
            },
        );
        self.type_counts.insert(type_tag, current + 1);

        Ok(handle)
    }

    /// 通过句柄获取强类型资源。
    ///
    /// 这里做了两层校验：
    /// - 句柄 id 是否存在；
    /// - 句柄 type_tag 与存储 type_tag 是否一致。
    ///
    /// 最后再执行 `Any` 向具体类型 `T` 的 downcast。
    pub fn get<T>(&self, handle: &ResourceHandle) -> ForgeResult<Arc<T>>
    where
        T: Any + Send + Sync + 'static,
    {
        let entry = self
            .resources
            .get(&handle.id)
            .ok_or_else(|| ForgeError::HandleNotFound {
                id: handle.id,
                type_tag: handle.type_tag.clone(),
            })?;

        if entry.type_tag != handle.type_tag {
            return Err(ForgeError::HandleNotFound {
                id: handle.id,
                type_tag: handle.type_tag.clone(),
            });
        }

        let value = entry.value.clone();
        Arc::downcast::<T>(value).map_err(|_| {
            ForgeError::Resource(format!(
                "resource type mismatch for handle {}, expected {}",
                handle.id, handle.type_tag
            ))
        })
    }

    /// 删除资源并维护类型计数。
    pub fn remove(&self, handle: &ResourceHandle) -> ForgeResult<()> {
        let (_, removed) =
            self.resources
                .remove(&handle.id)
                .ok_or_else(|| ForgeError::HandleNotFound {
                    id: handle.id,
                    type_tag: handle.type_tag.clone(),
                })?;

        let type_tag = removed.type_tag;
        if let Some(mut count) = self.type_counts.get_mut(&type_tag) {
            *count = count.saturating_sub(1);
            if *count == 0 {
                drop(count);
                self.type_counts.remove(&type_tag);
            }
        }

        Ok(())
    }

    /// 当前资源总数。
    pub fn count(&self) -> usize {
        self.resources.len()
    }

    /// 指定类型资源数量。
    pub fn count_by_type(&self, type_tag: &str) -> usize {
        self.type_counts.get(type_tag).map(|v| *v).unwrap_or(0)
    }

    /// 清空全部资源（通常只在测试或 runtime 关闭时使用）。
    pub fn clear(&self) {
        self.resources.clear();
        self.type_counts.clear();
    }
}

impl fmt::Debug for ResourceManager {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("ResourceManager")
            .field("resource_count", &self.resources.len())
            .field("type_count", &self.type_counts.len())
            .field("limits", &self.limits)
            .finish()
    }
}
