use proc_macro::TokenStream;

#[proc_macro_attribute]
pub fn forge_plugin(_attr: TokenStream, item: TokenStream) -> TokenStream {
    item
}

#[proc_macro_attribute]
pub fn forge_functions(_attr: TokenStream, item: TokenStream) -> TokenStream {
    item
}

#[proc_macro_attribute]
pub fn guarded(_attr: TokenStream, item: TokenStream) -> TokenStream {
    item
}
