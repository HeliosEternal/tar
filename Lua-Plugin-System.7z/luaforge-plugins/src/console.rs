use luaforge_core::context::ForgeContext;
use luaforge_core::error::ForgeResult;
use luaforge_core::plugin::{ForgePlugin, PluginKind};
use luaforge_core::registrar::LuaRegistrar;

#[derive(Debug, Clone, Default)]
pub struct ConsolePlugin;

impl ForgePlugin for ConsolePlugin {
    fn id(&self) -> &'static str {
        "forge.console"
    }

    fn name(&self) -> &'static str {
        "Console"
    }

    fn version(&self) -> &'static str {
        "0.1.0"
    }

    fn kind(&self) -> PluginKind {
        PluginKind::Builtin
    }

    fn register(&self, reg: &mut LuaRegistrar<'_>, _ctx: &ForgeContext) -> ForgeResult<()> {
        reg.add_function("log", |_lua, msg: String| {
            println!("[forge.log] {msg}");
            tracing::info!(target: "forge.console", "{msg}");
            Ok(())
        })?;

        reg.add_function("info", |_lua, msg: String| {
            println!("[forge.info] {msg}");
            tracing::info!(target: "forge.console", "{msg}");
            Ok(())
        })?;

        reg.add_function("warn", |_lua, msg: String| {
            eprintln!("[forge.warn] {msg}");
            tracing::warn!(target: "forge.console", "{msg}");
            Ok(())
        })?;

        reg.add_function("error", |_lua, msg: String| {
            eprintln!("[forge.error] {msg}");
            tracing::error!(target: "forge.console", "{msg}");
            Ok(())
        })?;

        Ok(())
    }
}
