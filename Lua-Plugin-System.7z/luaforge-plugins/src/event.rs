use luaforge_core::context::ForgeContext;
use luaforge_core::error::ForgeResult;
use luaforge_core::plugin::{ForgePlugin, PluginKind};
use luaforge_core::registrar::LuaRegistrar;
use mlua::{Function, Lua, Table, Value};

const LISTENER_STORE_KEY: &str = "__forge_event_listeners";

#[derive(Debug, Clone, Default)]
pub struct EventPlugin;

impl ForgePlugin for EventPlugin {
    fn id(&self) -> &'static str {
        "forge.event"
    }

    fn name(&self) -> &'static str {
        "Event"
    }

    fn version(&self) -> &'static str {
        "0.1.0"
    }

    fn kind(&self) -> PluginKind {
        PluginKind::Builtin
    }

    fn register(&self, reg: &mut LuaRegistrar<'_>, _ctx: &ForgeContext) -> ForgeResult<()> {
        reg.add_function("on", |lua, (event, callback): (String, Function)| {
            let store = listener_store(lua)?;
            let listeners = match store.get::<Option<Table>>(event.as_str())? {
                Some(t) => t,
                None => {
                    let t = lua.create_table()?;
                    store.set(event.clone(), t.clone())?;
                    t
                }
            };

            let idx = listeners.raw_len() + 1;
            listeners.raw_set(idx, callback)?;
            Ok(idx as i64)
        })?;

        reg.add_function("emit", |lua, (event, payload): (String, Value)| {
            let store = listener_store(lua)?;
            let Some(listeners) = store.get::<Option<Table>>(event.as_str())? else {
                return Ok(0i64);
            };

            let mut called = 0i64;
            for cb in listeners.sequence_values::<Function>() {
                let cb = cb?;
                cb.call::<()>(payload.clone())?;
                called += 1;
            }
            Ok(called)
        })?;

        reg.add_function("off", |lua, event: String| {
            let store = listener_store(lua)?;
            if store.contains_key(event.as_str())? {
                store.set(event, Value::Nil)?;
                Ok(true)
            } else {
                Ok(false)
            }
        })?;

        reg.add_function("count", |lua, event: String| {
            let store = listener_store(lua)?;
            match store.get::<Option<Table>>(event.as_str())? {
                Some(listeners) => Ok(listeners.raw_len() as i64),
                None => Ok(0i64),
            }
        })?;

        Ok(())
    }
}

fn listener_store(lua: &Lua) -> mlua::Result<Table> {
    let globals = lua.globals();
    match globals.get::<Option<Table>>(LISTENER_STORE_KEY)? {
        Some(store) => Ok(store),
        None => {
            let store = lua.create_table()?;
            globals.set(LISTENER_STORE_KEY, store.clone())?;
            Ok(store)
        }
    }
}
