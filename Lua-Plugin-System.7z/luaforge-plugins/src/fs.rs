use std::fs;

use luaforge_core::context::ForgeContext;
use luaforge_core::error::ForgeResult;
use luaforge_core::permission::Permission;
use luaforge_core::plugin::{ForgePlugin, PluginKind};
use luaforge_core::registrar::LuaRegistrar;

static FS_PERMISSIONS: [Permission; 3] = [
    Permission::new_static("fs.read"),
    Permission::new_static("fs.write"),
    Permission::new_static("fs.delete"),
];

#[derive(Debug, Clone, Default)]
pub struct FsPlugin;

impl ForgePlugin for FsPlugin {
    fn id(&self) -> &'static str {
        "forge.fs"
    }

    fn name(&self) -> &'static str {
        "FileSystem"
    }

    fn version(&self) -> &'static str {
        "0.1.0"
    }

    fn kind(&self) -> PluginKind {
        PluginKind::Builtin
    }

    fn required_permissions(&self) -> &[Permission] {
        &FS_PERMISSIONS
    }

    fn register(&self, reg: &mut LuaRegistrar<'_>, _ctx: &ForgeContext) -> ForgeResult<()> {
        reg.add_guarded_function("read_text", "fs.read", |_lua, path: String| {
            fs::read_to_string(path).map_err(mlua::Error::external)
        })?;

        reg.add_guarded_function(
            "write_text",
            "fs.write",
            |_lua, (path, content): (String, String)| {
                fs::write(path, content).map_err(mlua::Error::external)
            },
        )?;

        reg.add_guarded_function(
            "append_text",
            "fs.write",
            |_lua, (path, content): (String, String)| {
                use std::io::Write;
                let mut file = fs::OpenOptions::new()
                    .create(true)
                    .append(true)
                    .open(path)
                    .map_err(mlua::Error::external)?;
                file.write_all(content.as_bytes())
                    .map_err(mlua::Error::external)
            },
        )?;

        reg.add_guarded_function("remove_file", "fs.delete", |_lua, path: String| {
            fs::remove_file(path).map_err(mlua::Error::external)
        })?;

        reg.add_guarded_function("create_dir_all", "fs.write", |_lua, path: String| {
            fs::create_dir_all(path).map_err(mlua::Error::external)
        })?;

        reg.add_function("exists", |_lua, path: String| {
            Ok(std::path::Path::new(&path).exists())
        })?;

        Ok(())
    }
}
