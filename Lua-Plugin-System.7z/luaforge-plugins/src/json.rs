use luaforge_core::context::ForgeContext;
use luaforge_core::error::ForgeResult;
use luaforge_core::plugin::{ForgePlugin, PluginKind};
use luaforge_core::registrar::LuaRegistrar;
use mlua::{LuaSerdeExt, Value};

#[derive(Debug, Clone, Default)]
pub struct JsonPlugin;

impl ForgePlugin for JsonPlugin {
    fn id(&self) -> &'static str {
        "forge.json"
    }

    fn name(&self) -> &'static str {
        "Json"
    }

    fn version(&self) -> &'static str {
        "0.1.0"
    }

    fn kind(&self) -> PluginKind {
        PluginKind::Builtin
    }

    fn register(&self, reg: &mut LuaRegistrar<'_>, _ctx: &ForgeContext) -> ForgeResult<()> {
        reg.add_function("encode", |lua, value: Value| {
            let json_value: serde_json::Value = lua.from_value(value)?;
            serde_json::to_string(&json_value).map_err(mlua::Error::external)
        })?;

        reg.add_function("pretty", |lua, value: Value| {
            let json_value: serde_json::Value = lua.from_value(value)?;
            serde_json::to_string_pretty(&json_value).map_err(mlua::Error::external)
        })?;

        reg.add_function("decode", |lua, text: String| {
            let json: serde_json::Value =
                serde_json::from_str(&text).map_err(mlua::Error::external)?;
            lua.to_value(&json)
        })?;

        Ok(())
    }
}
