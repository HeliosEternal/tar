use std::sync::Arc;

use luaforge_core::context::ForgeContext;
use luaforge_core::error::ForgeResult;
use luaforge_core::registry::PluginRegistry;
use mlua::Lua;

#[cfg(feature = "plugin-console")]
pub mod console;
#[cfg(feature = "plugin-event")]
pub mod event;
#[cfg(feature = "plugin-fs")]
pub mod fs;
#[cfg(feature = "plugin-json")]
pub mod json;
#[cfg(feature = "plugin-sys")]
pub mod sys;
#[cfg(feature = "plugin-timer")]
pub mod timer;

pub fn register_default_plugins(
    registry: &PluginRegistry,
    lua: &Lua,
    ctx: &ForgeContext,
) -> ForgeResult<()> {
    #[cfg(feature = "plugin-sys")]
    registry.load(sys::SysPlugin::default(), lua, ctx)?;

    #[cfg(feature = "plugin-console")]
    registry.load(console::ConsolePlugin::default(), lua, ctx)?;

    #[cfg(feature = "plugin-json")]
    registry.load(json::JsonPlugin::default(), lua, ctx)?;

    #[cfg(feature = "plugin-timer")]
    registry.load(timer::TimerPlugin::default(), lua, ctx)?;

    #[cfg(feature = "plugin-event")]
    registry.load(event::EventPlugin::default(), lua, ctx)?;

    #[cfg(feature = "plugin-fs")]
    registry.load(fs::FsPlugin::default(), lua, ctx)?;

    Ok(())
}

pub fn register_default_factories(registry: &PluginRegistry) {
    #[cfg(feature = "plugin-sys")]
    registry.register_factory("forge.sys", || Arc::new(sys::SysPlugin::default()));

    #[cfg(feature = "plugin-console")]
    registry.register_factory("forge.console", || {
        Arc::new(console::ConsolePlugin::default())
    });

    #[cfg(feature = "plugin-json")]
    registry.register_factory("forge.json", || Arc::new(json::JsonPlugin::default()));

    #[cfg(feature = "plugin-timer")]
    registry.register_factory("forge.timer", || Arc::new(timer::TimerPlugin::default()));

    #[cfg(feature = "plugin-event")]
    registry.register_factory("forge.event", || Arc::new(event::EventPlugin::default()));

    #[cfg(feature = "plugin-fs")]
    registry.register_factory("forge.fs", || Arc::new(fs::FsPlugin::default()));
}
