use std::time::{SystemTime, UNIX_EPOCH};

use luaforge_core::context::ForgeContext;
use luaforge_core::error::ForgeResult;
use luaforge_core::plugin::{ForgePlugin, PluginKind};
use luaforge_core::registrar::LuaRegistrar;

#[derive(Debug, Clone, Default)]
pub struct SysPlugin;

impl ForgePlugin for SysPlugin {
    fn id(&self) -> &'static str {
        "forge.sys"
    }

    fn name(&self) -> &'static str {
        "System"
    }

    fn version(&self) -> &'static str {
        "0.1.0"
    }

    fn kind(&self) -> PluginKind {
        PluginKind::Builtin
    }

    fn register(&self, reg: &mut LuaRegistrar<'_>, _ctx: &ForgeContext) -> ForgeResult<()> {
        reg.add_function("os", |_lua, ()| Ok(std::env::consts::OS.to_string()))?;
        reg.add_function("arch", |_lua, ()| Ok(std::env::consts::ARCH.to_string()))?;

        reg.add_function("pid", |_lua, ()| Ok(std::process::id() as i64))?;

        reg.add_function("current_dir", |_lua, ()| {
            let dir = std::env::current_dir().map_err(mlua::Error::external)?;
            Ok(dir.to_string_lossy().to_string())
        })?;

        reg.add_function("temp_dir", |_lua, ()| {
            Ok(std::env::temp_dir().to_string_lossy().to_string())
        })?;

        reg.add_function("home_dir", |_lua, ()| {
            let home = std::env::var("HOME")
                .ok()
                .or_else(|| std::env::var("USERPROFILE").ok());
            Ok(home)
        })?;

        reg.add_function("env_get", |_lua, key: String| Ok(std::env::var(key).ok()))?;

        reg.add_function("now_unix_ms", |_lua, ()| {
            let now = SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .map_err(mlua::Error::external)?;
            Ok(now.as_millis() as i64)
        })?;

        Ok(())
    }
}
