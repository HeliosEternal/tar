use std::thread;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use luaforge_core::context::ForgeContext;
use luaforge_core::error::ForgeResult;
use luaforge_core::plugin::{ForgePlugin, PluginKind};
use luaforge_core::registrar::LuaRegistrar;
use mlua::Function;

#[derive(Debug, Clone, Default)]
pub struct TimerPlugin;

impl ForgePlugin for TimerPlugin {
    fn id(&self) -> &'static str {
        "forge.timer"
    }

    fn name(&self) -> &'static str {
        "Timer"
    }

    fn version(&self) -> &'static str {
        "0.1.0"
    }

    fn kind(&self) -> PluginKind {
        PluginKind::Builtin
    }

    fn register(&self, reg: &mut LuaRegistrar<'_>, _ctx: &ForgeContext) -> ForgeResult<()> {
        reg.add_function("sleep", |_lua, ms: u64| {
            thread::sleep(Duration::from_millis(ms));
            Ok(())
        })?;

        reg.add_function("set_timeout", |_lua, (ms, callback): (u64, Function)| {
            thread::sleep(Duration::from_millis(ms));
            callback.call::<()>(())
        })?;

        reg.add_function(
            "set_interval",
            |_lua, (ms, times, callback): (u64, u32, Function)| {
                for i in 0..times {
                    thread::sleep(Duration::from_millis(ms));
                    callback.call::<()>(i + 1)?;
                }
                Ok(())
            },
        )?;

        reg.add_function("now_ms", |_lua, ()| {
            let now = SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .map_err(mlua::Error::external)?;
            Ok(now.as_millis() as i64)
        })?;

        Ok(())
    }
}
