use luaforge_runtime::{ForgeConfig, ForgeRuntime};

fn main() {
    let runtime = ForgeRuntime::new(ForgeConfig::default()).expect("runtime init failed");
    runtime
        .exec(
            r#"
            forge.console.log("LuaForge started")
            print("OS:", forge.sys.os(), "ARCH:", forge.sys.arch())
        "#,
        )
        .expect("lua exec failed");
}
