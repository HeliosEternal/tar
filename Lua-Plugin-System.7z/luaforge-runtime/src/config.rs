use luaforge_core::permission::{PermissionLevel, PermissionPolicy};
use luaforge_core::resource::PoolConfig;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PromptMode {
    AllowAll,
    DenyAll,
}

#[derive(Debug, Clone)]
pub struct ForgeConfig {
    pub permission_policy: PermissionPolicy,
    pub prompt_mode: PromptMode,
    pub resource_limits: PoolConfig,
    pub auto_load_builtin_plugins: bool,
}

impl Default for ForgeConfig {
    fn default() -> Self {
        let mut policy = PermissionPolicy::new(PermissionLevel::Open);
        policy.add_rule("fs.write", PermissionLevel::Prompt);
        policy.add_rule("fs.delete", PermissionLevel::AlwaysAsk);
        policy.add_rule("shell.exec", PermissionLevel::AlwaysAsk);

        Self {
            permission_policy: policy,
            prompt_mode: PromptMode::AllowAll,
            resource_limits: PoolConfig::default(),
            auto_load_builtin_plugins: true,
        }
    }
}
