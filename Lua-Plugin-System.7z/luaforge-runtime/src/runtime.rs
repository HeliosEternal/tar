use std::sync::Arc;

use luaforge_core::context::{self, ForgeContext};
use luaforge_core::error::ForgeResult;
use luaforge_core::permission::{
    AllowAllPromptHandler, DenyAllPromptHandler, PermissionGate, PermissionPromptHandler,
};
use luaforge_core::plugin::ForgePlugin;
use luaforge_core::registry::PluginRegistry;
use luaforge_core::resource::ResourceManager;
use mlua::Lua;

use crate::config::{ForgeConfig, PromptMode};

/// `ForgeRuntime` 是宿主应用与 LuaForge 框架交互的主入口。
///
/// 宿主通常只需要持有这一个对象，即可完成：
/// - Lua 脚本执行；
/// - 插件加载/卸载；
/// - 上下文与注册中心访问。
pub struct ForgeRuntime {
    /// Lua 虚拟机实例。
    lua: Lua,
    /// 运行时共享上下文（权限、资源等）。
    ctx: ForgeContext,
    /// 插件注册中心。
    registry: Arc<PluginRegistry>,
}

impl ForgeRuntime {
    /// 初始化运行时。
    ///
    /// 初始化顺序非常关键：
    /// 1. 创建 Lua VM；
    /// 2. 根据配置构建权限网关与资源管理器；
    /// 3. 注入 `ForgeContext` 到 Lua app_data；
    /// 4. 初始化插件注册中心并注册 Lua 管理 API；
    /// 5. 注册内置插件工厂并按配置自动加载内置插件。
    pub fn new(config: ForgeConfig) -> ForgeResult<Self> {
        let lua = Lua::new();

        // 根据宿主配置选择“授权询问策略”。
        // 当前提供两种内置策略（全允许/全拒绝），后续可扩展为 UI 弹窗策略。
        let prompt_handler: Arc<dyn PermissionPromptHandler> = match config.prompt_mode {
            PromptMode::AllowAll => Arc::new(AllowAllPromptHandler),
            PromptMode::DenyAll => Arc::new(DenyAllPromptHandler),
        };

        // 构建核心上下文并注入 Lua VM。
        // 注意：许多框架内部 API 会直接从 app_data 读取上下文，因此必须先 set。
        let permissions = Arc::new(PermissionGate::with_handler(
            config.permission_policy,
            prompt_handler,
        ));
        let resources = Arc::new(ResourceManager::new(config.resource_limits));
        let ctx = ForgeContext::new(permissions, resources);
        context::set_forge_context(&lua, ctx.clone());

        // 初始化注册中心，并先暴露 `forge.plugins.*` 管理接口。
        let registry = Arc::new(PluginRegistry::new());
        luaforge_plugins::register_default_factories(&registry);
        PluginRegistry::register_lua_api(registry.clone(), &lua)?;

        // 按配置决定是否自动加载内置插件。
        if config.auto_load_builtin_plugins {
            luaforge_plugins::register_default_plugins(&registry, &lua, &ctx)?;
        }

        Ok(Self { lua, ctx, registry })
    }

    /// 执行一段 Lua 脚本。
    pub fn exec(&self, script: &str) -> ForgeResult<()> {
        self.lua.load(script).exec()?;
        Ok(())
    }

    /// 直接加载一个插件实例（宿主显式注入）。
    pub fn load_plugin(&self, plugin: impl ForgePlugin) -> ForgeResult<()> {
        self.registry.load(plugin, &self.lua, &self.ctx)
    }

    /// 按 id 通过工厂加载插件。
    pub fn load_plugin_by_id(&self, plugin_id: &str) -> ForgeResult<()> {
        self.registry.load_by_id(plugin_id, &self.lua, &self.ctx)
    }

    /// 卸载指定插件。
    pub fn unload_plugin(&self, plugin_id: &str) -> ForgeResult<()> {
        self.registry.unload(plugin_id, &self.lua, &self.ctx)
    }

    /// 获取 Lua VM 引用（高级场景）。
    pub fn lua(&self) -> &Lua {
        &self.lua
    }

    /// 获取共享上下文。
    pub fn context(&self) -> &ForgeContext {
        &self.ctx
    }

    /// 获取插件注册中心。
    pub fn registry(&self) -> &Arc<PluginRegistry> {
        &self.registry
    }
}

impl std::fmt::Debug for ForgeRuntime {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("ForgeRuntime")
            .field("registry", &self.registry)
            .field("context", &self.ctx)
            .finish()
    }
}
