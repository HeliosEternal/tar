use luaforge_core::context::ForgeContext;
use luaforge_core::error::ForgeResult;
use luaforge_core::permission::Permission;
use luaforge_core::plugin::{ForgePlugin, PluginKind};
use luaforge_core::registrar::LuaRegistrar;
use luaforge_runtime::{ForgeConfig, ForgeRuntime};

#[test]
fn runtime_loads_builtin_plugins() {
    let rt = ForgeRuntime::new(ForgeConfig::default()).unwrap();

    rt.exec(
        r#"
        assert(forge ~= nil)
        assert(forge.sys ~= nil)
        assert(type(forge.sys.os()) == "string")
        assert(forge.console ~= nil)
        assert(forge.json ~= nil)
        assert(forge.fs ~= nil)
    "#,
    )
    .unwrap();
}

#[test]
fn plugin_registry_api_works_from_lua() {
    let rt = ForgeRuntime::new(ForgeConfig::default()).unwrap();

    rt.exec(
        r#"
        local list = forge.plugins.list()
        assert(#list >= 1)

        local info = forge.plugins.info("forge.sys")
        assert(info ~= nil)
        assert(info.id == "forge.sys")
        assert(info.kind == "builtin")
    "#,
    )
    .unwrap();
}

#[test]
fn fs_plugin_respects_permission_policy() {
    let rt = ForgeRuntime::new(ForgeConfig::default()).unwrap();

    rt.exec(
        r#"
        local path = "./.luaforge_test_tmp.txt"
        forge.fs.write_text(path, "hello")
        local content = forge.fs.read_text(path)
        assert(content == "hello")
        forge.fs.remove_file(path)
    "#,
    )
    .unwrap();
}

#[test]
fn user_plugin_can_be_loaded() {
    #[derive(Clone)]
    struct GreetPlugin;

    impl ForgePlugin for GreetPlugin {
        fn id(&self) -> &'static str {
            "forge.greet"
        }

        fn name(&self) -> &'static str {
            "Greet"
        }

        fn version(&self) -> &'static str {
            "0.1.0"
        }

        fn kind(&self) -> PluginKind {
            PluginKind::User
        }

        fn required_permissions(&self) -> &[Permission] {
            &[]
        }

        fn register(&self, reg: &mut LuaRegistrar<'_>, _ctx: &ForgeContext) -> ForgeResult<()> {
            reg.add_function("hello", |_lua, name: String| Ok(format!("hello, {name}")))?;
            Ok(())
        }
    }

    let rt = ForgeRuntime::new(ForgeConfig::default()).unwrap();
    rt.load_plugin(GreetPlugin).unwrap();

    let msg: String = rt
        .lua()
        .load(r#"return forge.greet.hello("Lua")"#)
        .eval()
        .unwrap();
    assert_eq!(msg, "hello, Lua");
}
